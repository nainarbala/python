student_count = 1000
rating = 4.99
is_pulished = False
course_name = "Python program"
print(student_count, rating, is_pulished, course_name)
