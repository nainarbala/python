numbers = [2,4,5,6,7,7,2,1,4,6, 19]

x, *o, y = numbers
print(x)
print(o)
print(y)