
letters = ["a", "b", "c", "d"]
matrix = [[1,2], [3,2]]
zeros = [0] * 5

combined = letters + zeros

numbers = list(range(1,20))
chars = list('Yanhoo and gogole')

print(len(chars))
print(len(numbers))
print(chars)
print(numbers)
print(letters)
print(matrix)
print(zeros)
print(combined)