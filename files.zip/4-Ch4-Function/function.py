def greet(fname, lname):
    print("Helo world")
    print("pythin")
    print(f"{fname} {lname}")

    
greet("AAAA", "BBBBB")