# print(10 + 2)
# print(10 - 2)
# print(10 * 2)
# print(10 / 2)
# print(10 // 3)  # Floor division
# print(10 % 3)   # Modulus
# print(10 ** 2)  # Exponentiation
# print(10 + 3 * 2)
# print((10 + 3) * 2)
# print(10 + 3 * 2 - 5)
# print(10 + 3 * (2 - 5))
# print(10 + 3 * (2 - 5) / 2)
# print(10 + 3 * (2 - 5) // 2)
# print(10 + 3 * (2 - 5) % 2)
# print(10 + 3 * (2 - 5) ** 2)
# print(10 + 3 * (2 - 5) ** 2 // 2)
# print(10 + 3 * (2 - 5) ** 2 % 2)

print(10 / 2)
print(10 % 2)
print(10 // 2)
print(10 / 3)
print(10 // 3)
print(10 % 3)

print(2 * 3)
print(2 ** 3)
x = 2
print(x)
x += 2
print(x)
x **= 2
print(x)
print(4 ** 2)