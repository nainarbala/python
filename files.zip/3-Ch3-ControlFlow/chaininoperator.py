age = 22

# if age <= 18 and age < 60:
#     message = "Eligible to vote"
#     print(message)


if 18 <= age < 60:
    message = "Eligible to vote"
    print(message)