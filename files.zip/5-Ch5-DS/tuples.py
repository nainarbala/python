point =(1,2,3,4) * 4
point1 =[1,2,3,4] * 4

print(type(point))
print(point)

print(type(point1))
print(point1)