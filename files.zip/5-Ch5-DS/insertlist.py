letters = ["a", "b", "c", "d"]
print(letters.pop())
print(letters)
print(letters.append("d"))
print(letters)
print(letters.insert(0, "x"))
print(letters)