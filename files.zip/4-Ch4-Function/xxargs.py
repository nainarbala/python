def greet(**user):
    print(user)
    print(user["name"])


greet(id=1, name="Bala", age = 20)