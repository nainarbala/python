def sales():
    return  "This is sale function........"

def shipping():
    return True;

