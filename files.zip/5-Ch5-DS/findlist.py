letters = ["a", "b","c"]
           
print(letters.count("a"))
if "x" in letters:
    print("present")

print(letters.index("a"))
print(letters.index("xz"))
