def increment(num, by):
    return num + by

print(increment(num=5, by=10))