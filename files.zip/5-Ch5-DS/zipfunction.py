list1 = [1,2,3, 4]
list2 = [11,21,13, 5]

print(list(zip("abcd", list1, list2)))