course = "    Python Programming"

print(course.lower)
