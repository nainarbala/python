from pathlib import Path
from zipfile import ZipFile

path = Path();

with ZipFile("files.zip", "w") as zip:
    for p in path.rglob("*.*"):
        zip.write(p)

        


