age = 22
if age >= 18:
    message = "Eligible to vote"
else:
    message = "Not eligible to vote"
print(message)

message = "Eligaibel" if age > 50 else "Not eligible"
print(message)