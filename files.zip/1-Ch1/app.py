print("Hello world")
print("#" * 20)

a = 2+2
print(a)

print("Testing")
