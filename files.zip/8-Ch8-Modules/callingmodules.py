from modules import sales, shipping


print(sales())
print(shipping())