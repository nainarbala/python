course = "This is a string"
print(course.upper())
print(course.lower())
print(course.title())
print(course.replace('T', 'X'))
print(course)
print('This' in course)
print('xxx' not in course)
print(course.find('This'))
