temparature = 35
if temparature > 30:
    print("It's a hot day")
elif temparature > 20:
    print("It's a nice day")
elif temparature > 10:
    print("It's a bit chilly")
else:
    print("It's cold day")