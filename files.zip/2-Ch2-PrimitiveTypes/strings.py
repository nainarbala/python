course = "Python Programming"

print(len(course))
print(course[0])
print(course[-17])
print(course[-18])

count = len(course)+10
print(len(course)+10)
print(course[0:28])

course1 = "Pythin \\Test"
print(course1)

name = "John"
print(name[0:-10])
