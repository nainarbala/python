command = input("Enter a command: ")
while command.lower() != "quit":
    print("You entered:", command)
    command = input("Enter a command: ")