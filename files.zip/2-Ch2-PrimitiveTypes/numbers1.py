import math

print(round(2.1))
print(round(2.0))
print(round(2.9))
print(round(2.4))
print(round(2.5))
print(round(2.6))

print(abs(-2000))

print(math.ceil(2.1))
print(math.ceil(2.0))
print(math.ceil(2.999999))
print(math.ceil(2.00000000001))