from sys import path

print(path)
print("*" * 20)
#print(sys.path)