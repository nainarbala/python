def incremetn(number , by =1):
    return number + by

print(incremetn(10))
print(incremetn(10, 10))