numbers = list(range(20))

print(numbers[::-1])
print(numbers[::1])
print(numbers)