from ecommerce.shopping import sales1

print(sales1.sales1())

dirs = dir(sales1)
print(dirs)
for dir in dirs:
    print(dir)

print(sales1.__builtins__)
print(sales1.__cached__)
print(sales1.__doc__)
print(sales1.__file__)
print(sales1.__name__)
print(sales1.__package__)
print(sales1.__spec__)
