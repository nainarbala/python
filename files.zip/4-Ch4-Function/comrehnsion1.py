list1 = [item * 2 for item in range(5)]
print(list1)

set1 = {item * 2 for item in range (5)}
print(set1)

dict1 = {item: item*2 for item in range(5)}
print(dict1)

tuple1 = (item * 2 for item in range(5))
print(tuple1)