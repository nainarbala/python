
def calc_price():
    return "this is calc_price"

def calc_shipping():
    return "this is calc_shipping"