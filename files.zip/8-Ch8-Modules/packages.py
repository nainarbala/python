from ecommerce.sales import calc_price, calc_shipping
from ecommerce.shopping.sales1 import sales1


print(calc_price())
print(calc_shipping())
print(sales1())