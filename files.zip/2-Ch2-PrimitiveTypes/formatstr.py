first_name = "Python"
second_name = "Programming"
print(f"{first_name} {second_name} {2 * 10} {"*" * 10}")
print(F"{first_name} {second_name} {2 * 10} {"*" * 10}")