
def greet(name):
    print(f"Hi {name}")

print(greet("xxx"))